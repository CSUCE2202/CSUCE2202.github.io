close all;
clear all;
clc;

% Load data from Excel file "Question2.xlsx"
data = xlsread("Question2.xlsx");

% Define variables
Year = 1:11;
log_Year = log(Year);
Patent_count = data(:, 3);
Policy_benefit = data(:, 4);
Charging_piles = data(:, 5);

% Perform linear and quadratic fits
P_1 = polyfit(log_Year, Patent_count, 1);
P_2 = polyfit(log_Year, Policy_benefit, 2);
P_3 = polyfit(log_Year, Charging_piles, 2);

% Generate a range of years for prediction
year = 1:22;
log_year = log(year);
Patent_pred = log_year * P_1(1) + P_1(2);
Policy_pred = P_2(3) + P_2(2) * log_year + P_2(1) * log_year.^2;
Charging_pred = P_3(3) + P_3(2) * log_year + P_3(1) * log_year.^2;

combined_fig = figure();

% Create subplots for visualization
subplot(1, 3, 1)
plot(Year, Patent_count, 'b')          % Plot original data in blue
hold on;
plot(year, Patent_pred, 'r')           % Plot predicted data in red

% Add labels and beautify the plot
xlabel('Year', 'FontName', 'Times New Roman', 'FontSize', 12);
ylabel('Patent Count', 'FontName', 'Times New Roman', 'FontSize', 12);
title('Patent Count Over Time', 'FontName', 'Times New Roman', 'FontSize', 14);
legend({'Original', 'Predicted'}, 'FontName', 'Times New Roman', 'FontSize', 10);
grid on;

subplot(1, 3, 2)
plot(Year, Policy_benefit, 'b')        % Plot original data in blue
hold on;
plot(year, Policy_pred, 'r')           % Plot predicted data in red

% Add labels and beautify the plot
xlabel('Year', 'FontName', 'Times New Roman', 'FontSize', 12);
ylabel('Policy Benefit', 'FontName', 'Times New Roman', 'FontSize', 12);
title('Policy Benefit Over Time', 'FontName', 'Times New Roman', 'FontSize', 14);
legend({'Original', 'Predicted'}, 'FontName', 'Times New Roman', 'FontSize', 10);
grid on;

subplot(1, 3, 3)
plot(Year, Charging_piles, 'b')        % Plot original data in blue
hold on;
plot(year, Charging_pred, 'r')         % Plot predicted data in red

% Add labels and beautify the plot
xlabel('Year', 'FontName', 'Times New Roman', 'FontSize', 12);
ylabel('Charging Piles', 'FontName', 'Times New Roman', 'FontSize', 12);
title('Charging Piles Over Time', 'FontName', 'Times New Roman', 'FontSize', 14);
legend({'Original', 'Predicted'}, 'FontName', 'Times New Roman', 'FontSize', 10);
grid on;
hold off;

close(combined_fig);

% Calculate the values of the fitted functions at year = 12:22
year_range = 12:22;
log_year_range = log(year_range);
Patent_pred_range = log_year_range * P_1(1) + P_1(2);
Policy_pred_range = P_2(3) + P_2(2) * log_year_range + P_2(1) * log_year_range.^2;
Charging_pred_range = P_3(3) + P_3(2) * log_year_range + P_3(1) * log_year_range.^2;

