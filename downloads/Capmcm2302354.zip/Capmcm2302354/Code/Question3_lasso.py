import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.linear_model import LassoCV
from sklearn.metrics import r2_score
import matplotlib.pyplot as plt
from matplotlib import rcParams

# Set the font family to Times New Roman
rcParams['font.family'] = 'serif'
rcParams['font.serif'] = 'Times New Roman'

# Create a DataFrame with the data
data = {
    'Electric car': [0, 0, 0.1, 0.2, 0.3, 0.5, 0.8, 1.2, 2, 2, 3.1, 6.6, 10.8],
    'Carbon emission': [7.00967, 7.1243796, 7.18268, 7.3703, 7.49429, 7.72898, 7.87605, 8.07551, 8.26884, 8.2669297, 7.09832, 7.73, 7.98],
    'Charging Piles': [34.72, 49.7, 71.15, 101.86, 145.82, 184, 331, 439, 549, 894, 1295, 1777, 2572.25],
    'Conventional car': [66.4, 71.2, 73.7, 77.3, 79.7, 81.3, 85.6, 85.1, 83.6, 79.3, 68.7, 68.3, 64]
}

df = pd.DataFrame(data)

# Split the data into independent and target variables
X = df[['Electric car', 'Carbon emission', 'Charging Piles']]
y = df['Conventional car']

# Normalize the independent variables using Min-Max scaling
scaler = MinMaxScaler()
X_scaled = scaler.fit_transform(X)

# Create a Lasso regression model
lasso = LassoCV(alphas=[0.001, 0.01, 0.1, 1.0, 10.0], cv=5)  # You can choose different alpha values as needed
lasso.fit(X_scaled, y)

# Get the best alpha value
best_alpha = lasso.alpha_

# Get the model coefficients
coefficients = lasso.coef_

# Predict the target variable
y_pred = lasso.predict(X_scaled)

# Calculate the R-squared value
r_squared = r2_score(y, y_pred)

# Output the best alpha value, model coefficients, and R-squared value
print("Best alpha value:", best_alpha)
print("Model coefficients:", coefficients)
print("R-squared value:", r_squared)

# Output the fitted equation
intercept = lasso.intercept_
coef_1, coef_2, coef_3 = coefficients
print("Fitted equation:")
print(f"Conventional car = {intercept:.2f} + {coef_1:.2f} * Electric car + {coef_2:.2f} * Carbon emission + {coef_3:.2f} * Charging Piles ")

# Create the plot with the Times New Roman font
plt.figure(figsize=(8, 6))
plt.scatter(y, y_pred, color='blue', label='True vs. Predicted')
plt.plot([min(y), max(y)], [min(y), max(y)], linestyle='--', color='red', linewidth=2, label='Ideal Line')
plt.xlabel('True Values')
plt.ylabel('Predicted Values')
plt.title('True vs. Predicted Values')
plt.legend()

# Save the plot as a PDF file
plt.savefig('Figure5.pdf', format='pdf', bbox_inches='tight')

# Show the plot (optional)
plt.show()
