import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import textwrap

# Create a DataFrame with the updated data
data = pd.DataFrame({
    'New Energy Vehicle Sales': [1.3, 1.8, 7.5, 32.9, 50.2, 76.8, 124.7, 120.6, 132.3, 350.7, 700.3],
    'The patent count ': [140,210,246,523,1420,3552,6103,4958,7058,7307,7028],
    'Policy benefit': [0, 5, 4, 5, 10, 6, 7, 10, 10, 29, 30],
    'Charging piles': [1.8,2.2872,2.8,5.8553,13.8233,21.3903,33.1294,51.6396,80.7398,14.7,306.2]
})

# Compute the correlation matrix for all variables
correlation_matrix = data.corr()

mask = np.triu(np.ones_like(correlation_matrix, dtype=bool))

# Set the font for matplotlib
plt.rcParams['font.family'] = 'Times New Roman'

# Create the first figure and heatmap
plt.figure(figsize=(5, 5))
plt.subplot(1, 2, 1)
target_correlation = correlation_matrix[['New Energy Vehicle Sales']].drop(['New Energy Vehicle Sales'])
# Wrap the labels
wrapped_labels = [textwrap.fill(label, width=15) for label in target_correlation.index]
sns.heatmap(target_correlation, annot=True, cmap='coolwarm', linewidths=1, cbar=False, xticklabels=['New Energy Vehicle Sales'])
plt.title('Correlation with New Energy Vehicle Sales')
plt.xticks(rotation=0)
plt.yticks(rotation=0)

# Save the first figure 
plt.savefig('figure1.pdf', format='pdf', bbox_inches='tight')

# Create the second figure and heatmap
plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 2)
remaining_correlation = correlation_matrix.drop(['New Energy Vehicle Sales'], axis=1).drop(['New Energy Vehicle Sales'], axis=0)
# Wrap the labels
wrapped_labels = [textwrap.fill(label, width=15) for label in remaining_correlation.index]
sns.heatmap(remaining_correlation, annot=True, cmap='coolwarm', linewidths=1, xticklabels=wrapped_labels)
plt.title('Correlation among Other Variables')
plt.xticks(rotation=0)
plt.yticks(rotation=0)

# Save the second figure 
plt.savefig('figure2.pdf', format='pdf', bbox_inches='tight')

plt.show()
