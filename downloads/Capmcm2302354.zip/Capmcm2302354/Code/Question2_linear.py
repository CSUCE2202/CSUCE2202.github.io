import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
from statsmodels.stats.outliers_influence import variance_inflation_factor
import statsmodels.api as sm

# Load the data
file_path = 'Question2.csv'  # Replace with your file path
data = pd.read_csv(file_path)

# Separate the data with and without sales values
data_with_sales = data.dropna(subset=['New Energy Vehicle Sales'])
data_missing_sales = data[data['New Energy Vehicle Sales'].isnull()]

# Define independent variables (features) and dependent variable (target)
features = ['The patent count in the new energy sector', 'Policy benefit', 'Charging piles(*10,000)']
target = 'New Energy Vehicle Sales'

# Prepare training and prediction data
X_train = data_with_sales[features]
y_train = data_with_sales[target]
X_missing = data_missing_sales[features]

# Create and train the linear regression model
model = LinearRegression()
model.fit(X_train, y_train)

# Predict the missing sales values
predicted_sales = model.predict(X_missing)
data_missing_sales['New Energy Vehicle Sales'] = predicted_sales

# Merge data and sort by year
complete_data = pd.concat([data_with_sales, data_missing_sales]).sort_index()

# Calculate R^2 for the model
r2 = model.score(X_train, y_train)

# Output the R^2 value
print(f"R^2 for the model: {r2:.4f}")

# Multicollinearity test using Variance Inflation Factor (VIF)
X_train_vif = sm.add_constant(X_train)
vif_data = pd.DataFrame()
vif_data["Feature"] = X_train_vif.columns
vif_data["VIF"] = [variance_inflation_factor(X_train_vif.values, i) for i in range(X_train_vif.shape[1])]

# Print VIF results in table format
print("\nVariance Inflation Factor (VIF) for each feature:")
print(vif_data.to_string(index=False))

# Matplotlib settings for Times New Roman
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 12

# Plot and save the sales over time as a vector graph
plt.figure(figsize=(12, 6))
plt.plot(data_with_sales['Year'], data_with_sales['New Energy Vehicle Sales'], marker='o', color='b', label='Actual Sales')
plt.plot(data_missing_sales['Year'], data_missing_sales['New Energy Vehicle Sales'], marker='o', color='r', label='Predicted Sales')

# Adding a red connecting line
if len(data_with_sales) > 0 and len(data_missing_sales) > 0:
    last_actual = data_with_sales.iloc[-1]
    first_predicted = data_missing_sales.iloc[0]
    plt.plot([last_actual['Year'], first_predicted['Year']], [last_actual['New Energy Vehicle Sales'], first_predicted['New Energy Vehicle Sales']], color='red')

plt.title('New Energy Vehicle Sales from 2012 to 2033', fontname='Times New Roman', fontsize=14)
plt.xlabel('Year', fontname='Times New Roman', fontsize=12)
plt.ylabel('Sales (in thousands)', fontname='Times New Roman', fontsize=12)
plt.legend()
plt.grid(True)
plt.savefig('Fogure5.svg', format='svg')  # Replace with your save path
plt.show()
