import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor
import matplotlib.font_manager as fm

# Load the actual data
actual_data = pd.DataFrame({
    "Year": [2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022],
    "New Energy Vehicle Sales": [1.3, 1.8, 7.5, 32.9, 50.2, 76.8, 124.7, 120.6, 132.3, 350.7, 700.3],
    "The patent count ": [140, 210, 246, 523, 1420, 3552, 6103, 4958, 7058, 7307, 7028],
    "Policy benefit": [0, 5, 4, 5, 10, 6, 7, 10, 10, 29, 30],
    "Charging piles": [1.8, 2.2872, 2.8, 5.8553, 13.8233, 21.3903, 33.1294, 51.6396, 80.7398, 114.7, 306.2],
    "The tax of other country": [2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 2.5, 27.5, 27.5, 27.5, 27.5]
})

# Prepare independent and dependent variables
X_actual = actual_data[['The patent count ', 'Policy benefit', 'Charging piles', 'The tax of other country']]
y_actual = actual_data['New Energy Vehicle Sales']

# Add a constant term for OLS regression
X_actual = sm.add_constant(X_actual)

# Create and fit the OLS model
model_ols = sm.OLS(y_actual, X_actual).fit()

# Print model summary including t-tests and F-test results
print(model_ols.summary())

# Calculate the correlation matrix
correlation_matrix = X_actual.drop('const', axis=1).corr()
print(correlation_matrix)

# Set font to Times New Roman
plt.rcParams['font.family'] = 'Times New Roman'

# Create a correlation heatmap
plt.figure(figsize=(10, 8))
sns.heatmap(correlation_matrix, annot=True, cmap="coolwarm", linewidths=2, fmt=".2f")
plt.title("Correlation Heatmap")
plt.xticks(rotation=0)
plt.yticks(rotation=0)
plt.tight_layout()
plt.savefig("Figure6.pdf", format="pdf")
plt.show()
