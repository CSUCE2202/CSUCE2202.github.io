import pandas as pd
import numpy as np
from sklearn.linear_model import Ridge
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import matplotlib.pyplot as plt

# Create a DataFrame
data = {
    "New Energy Vehicle Sales": [1.3, 1.8, 7.5, 32.9, 50.2, 76.8, 124.7, 120.6, 132.3, 350.7, 700.3],
    "Patent Count in New Energy Sector": [140, 210, 246, 523, 1420, 3552, 6103, 4958, 7058, 7307, 7028],
    "Policy Benefit": [0, 5, 4, 5, 10, 6, 7, 10, 10, 29, 30],
    "Charging Piles (*10,000)": [1.8, 2.2872, 2.8, 5.8553, 13.8233, 21.3903, 33.1294, 51.6396, 80.7398, 114.7, 306.2],
    "Tax of Other Country": [0.025, 0.025, 0.025, 0.025, 0.025, 0.025, 0.025, 0.275, 0.275, 0.275, 0.275]
}

df = pd.DataFrame(data)

# Separate features and target variable
X = df.drop("New Energy Vehicle Sales", axis=1)
y = df["New Energy Vehicle Sales"]

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Build a Ridge regression model
alpha = 10  # Hyperparameter to be adjusted for optimal performance
ridge = Ridge(alpha=alpha)

# Fit the model
ridge.fit(X_train, y_train)

# Predict
y_pred = ridge.predict(X_test)

# Calculate the root mean squared error
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
print("Root Mean Squared Error (RMSE):", rmse)

# Print model coefficients and R^2
print("Model coefficients:")
print(f"Intercept (Constant Term): {ridge.intercept_}")
for feature, coef in zip(X.columns, ridge.coef_):
    print(f"{feature}: {coef}")

# Calculate R^2
r_squared = ridge.score(X_test, y_test)
print("R-squared (R²):", r_squared)

# Create a Ridge Trace Plot
alphas = np.logspace(-6, 6, 13)  # Generate 13 alpha values from 10^-6 to 10^6
coefs = []

for alpha in alphas:
    ridge = Ridge(alpha=alpha)
    ridge.fit(X_train, y_train)
    coefs.append(ridge.coef_)

# Set the font family to Times New Roman
plt.rcParams['font.family'] = 'Times New Roman'

# Create the Ridge Trace Plot
plt.figure(figsize=(10, 6))
plt.plot(alphas, coefs)
plt.xscale('log')  # Use a logarithmic scale on the x-axis
plt.xlabel('Alpha (Regularization Strength)')
plt.ylabel('Coefficient Values')
plt.title('Ridge Trace Plot')
plt.legend(X.columns, loc='upper right')
plt.axis('tight')
plt.grid()

# Save the plot as a PDF vector graphic
plt.savefig("Figure7.pdf", format="pdf")
plt.show()
